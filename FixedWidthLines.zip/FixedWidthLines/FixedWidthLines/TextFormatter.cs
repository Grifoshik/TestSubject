﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FixedWidthLines
{
    class TextFormatter
    {
        private int CurrentPosition, SummaryLengthOfSubWord;
        private StringBuilder Result = new StringBuilder();
        public string Justify(string text, int width)
        {
            string[] Words = text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            
            CurrentPosition = 0;
            SummaryLengthOfSubWord = Words[0].Length;
            for (int i = 1; i < Words.Count(); i++)
            {
                if (SummaryLengthOfSubWord + Words[i].Length > width - (i - CurrentPosition))  // If summary length of words highers than width including places for space char
                {
                    if (i - CurrentPosition == 1) // In case of single word 
                    {
                        Result.Append(Words[CurrentPosition] + '\n');
                        //Result.Append(Words[CurrentPosition] + Environment.NewLine);   //In case of NonUnix System
                    }
                    else  //Other cases
                    {
                        int shift;
                        int freeSpace = width - SummaryLengthOfSubWord;
                        for (int j = CurrentPosition; j < i - 1; j++)
                        {
                            if ((freeSpace % (i - j - 1)) != 0)   //Bulding a non-increasing sequence of space char
                            {
                                shift = freeSpace / (i - j - 1);
                                shift += 1;
                            }
                            else
                            {
                                shift = freeSpace / (i - j - 1);
                            }
                            Result.Append(Words[j]);
                            for (int k = 0; k < shift; k++)
                            {
                                Result.Append(' ');
                            }
                            SummaryLengthOfSubWord -= Words[j].Length;
                            freeSpace -= shift;
                        }
                        Result.Append(Words[i - 1] + '\n');
                        //Result.Append(Words[i - 1] + Environment.NewLine);   //In case of NonUnix System
                    }
                    CurrentPosition = i;
                    SummaryLengthOfSubWord = Words[i].Length;
                }
                else
                {
                    SummaryLengthOfSubWord += Words[i].Length;
                }
            }
            for (int i = CurrentPosition; i < Words.Count() - 1; i++)  // Adding unformatted line in the end
            {
                Result.Append(Words[i] + ' ');
            }
            Result.Append(Words[Words.Count() - 1]);
            return Result.ToString();
        }
    }
}
