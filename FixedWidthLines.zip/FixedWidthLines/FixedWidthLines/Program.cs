﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace FixedWidthLines
{
    class Program
    {
        static void Main(string[] args)
        {
            string Text;
            int Width;
            using (StreamReader s = new StreamReader("Text.txt"))
            {
                Width = Int32.Parse(s.ReadLine());
                Text = s.ReadToEnd();
            }
            TextFormatter tf = new TextFormatter();
            using (StreamWriter file = new StreamWriter("Output.txt"))
            {
                file.Write(tf.Justify(Text, Width));
            }
        }
    }
}
